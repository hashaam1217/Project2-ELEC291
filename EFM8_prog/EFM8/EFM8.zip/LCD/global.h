#define SYSCLK    48000000L // SYSCLK frequency in Hz
#define BAUDRATE    115200L // Baud rate of UART in bps
